package com.undervold.hud.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.SeekBar
import com.undervold.hud.R

class VolHudOverlayService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())

    private var wm: WindowManager? = null
    private var panel: View? = null
    private var slider: SeekBar? = null

    private lateinit var audio: AudioManager

    // Auto-hide: no animation, just remove view after timeout.
    private val hideRunnable = Runnable { hideNow() }

    // Sound: short "tick" per user press / slider change.
    private var soundPool: SoundPool? = null
    private var tickSoundId: Int = 0

    // Short sampling burst to track volume changes even when key events are not delivered.
    private val sampleRunnable = object : Runnable {
        private var startMs: Long = 0
        override fun run() {
            if (startMs == 0L) startMs = System.currentTimeMillis()
            syncSliderFromSystem()
            val elapsed = System.currentTimeMillis() - startMs
            if (elapsed < 900) {
                mainHandler.postDelayed(this, 60)
            } else {
                startMs = 0
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        soundPool = SoundPool.Builder().setMaxStreams(1).build().also {
            tickSoundId = it.load(this, R.raw.vol_tick, 1)
        }

        startForegroundInternal()
    }

    override fun onDestroy() {
        super.onDestroy()
        hideNow()
        soundPool?.release()
        soundPool = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showOrRefresh()
        return START_STICKY
    }

    private fun startForegroundInternal() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "undervol_hud"

        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(
                channelId,
                "UnderVolume HUD",
                NotificationManager.IMPORTANCE_MIN
            )
            nm.createNotificationChannel(ch)
        }

        val notif = Notification.Builder(this, channelId)
            .setContentTitle("UnderVolume HUD")
            .setContentText("Listening for volume keys (Accessibility).")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .build()

        startForeground(1, notif)
    }

    private fun showOrRefresh() {
        if (!Settings.canDrawOverlays(this)) return

        if (panel == null) {
            val v = LayoutInflater.from(this).inflate(R.layout.volume_panel, null, false)

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                x = 24
            }

            wm?.addView(v, lp)
            panel = v

            val s = v.findViewById<SeekBar>(R.id.volumeSlider)
            slider = s
            s.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            s.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)

            // Slider changes set system volume + play tick.
            s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                        playTickForVolume(progress, seekBar.max)
                        scheduleHide()
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar) {
                    scheduleHide()
                }
                override fun onStopTrackingTouch(seekBar: SeekBar) {
                    scheduleHide()
                }
            })

            // Buttons
            v.findViewById<ImageButton>(R.id.btnMute).setOnClickListener {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                playTickForVolume(0, s.max)
                syncSliderFromSystem()
                scheduleHide()
            }

            v.findViewById<ImageButton>(R.id.btnClose).setOnClickListener {
                hideNow()
            }
        } else {
            syncSliderFromSystem()
        }

        scheduleHide()
        // Run a short sampling burst to keep slider accurate during key spam.
        mainHandler.removeCallbacks(sampleRunnable)
        mainHandler.post(sampleRunnable)
    }

    private fun syncSliderFromSystem() {
        val s = slider ?: return
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (cur != s.progress) s.progress = cur
    }

    private fun scheduleHide() {
        mainHandler.removeCallbacks(hideRunnable)
        mainHandler.postDelayed(hideRunnable, AUTO_HIDE_MS)
    }

    private fun hideNow() {
        mainHandler.removeCallbacks(hideRunnable)
        mainHandler.removeCallbacks(sampleRunnable)
        panel?.let { v ->
            try {
                wm?.removeView(v)
            } catch (_: Throwable) { }
        }
        panel = null
        slider = null
    }

    /**
     * Volume-dependent sound:
     * - Higher volume -> higher pitch (playbackRate).
     * - You can replace vol_tick.wav with an Undertale/Deltarune SFX you have rights to.
     */
    private fun playTickForVolume(cur: Int, max: Int) {
        val sp = soundPool ?: return
        if (tickSoundId == 0) return

        val norm = if (max <= 0) 0f else (cur.toFloat() / max.toFloat()).coerceIn(0f, 1f)

        // playbackRate range: 0.5 .. 2.0
        val rate = 0.75f + (norm * 1.0f)

        // Also scale volume a bit to feel responsive, but keep it subtle:
        val vol = 0.25f + (norm * 0.35f)

        sp.play(tickSoundId, vol, vol, 1, 0, rate)
    }

    companion object {
        private const val AUTO_HIDE_MS = 1200L

        fun requestShow(ctx: Context) {
            val i = Intent(ctx, VolHudOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
    }
}
