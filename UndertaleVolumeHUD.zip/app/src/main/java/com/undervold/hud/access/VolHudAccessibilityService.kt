package com.undervold.hud.access

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import com.undervold.hud.overlay.VolHudOverlayService

/**
 * Best-effort trigger:
 * - Some devices deliver volume key events to accessibility services, some don't.
 * - Even if keys are not delivered, the overlay still updates volume while visible.
 */
class VolHudAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        // no-op
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
                event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
                event.keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
            ) {
                VolHudOverlayService.requestShow(applicationContext)
            }
        }
        // return false so the system still changes volume normally
        return false
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) { }
    override fun onInterrupt() { }
}
