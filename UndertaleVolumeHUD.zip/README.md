# UnderVolume HUD (Accessibility + Overlay)

This project shows a custom volume HUD overlay (black background, thick white outline, custom corner images, custom thumb),
triggered best-effort via an AccessibilityService.

## Important (Undertale/Deltarune assets)
Undertale/Deltarune graphics and sounds are copyrighted. This repo includes **placeholder** corner images and thumb.
Replace them with assets you have rights to (or draw your own inspired-by pixel art).

## Features
- Overlay volume panel (TYPE_APPLICATION_OVERLAY)
- No animation, no dragging
- Auto-hide after ~1.2s
- Slider controls STREAM_MUSIC volume
- Mute button + Close button
- Tick sound on volume change; pitch/volume varies by volume level

## Setup
1. Open in Android Studio.
2. Sync Gradle.
3. Install on device (Android 8+; minSdk 26).
4. Enable:
   - Settings -> Accessibility -> UnderVolume HUD -> ON
   - Settings -> Special access -> Display over other apps -> Allow for UnderVolume HUD

## Replace assets
Put your own PNGs here:
- app/src/main/res/drawable/corner_tl.png
- app/src/main/res/drawable/corner_tr.png
- app/src/main/res/drawable/corner_bl.png
- app/src/main/res/drawable/corner_br.png
- app/src/main/res/drawable/slider_thumb.png

Replace the tick sound:
- app/src/main/res/raw/vol_tick.wav

## Notes / Limitations
- Some OEMs may not forward volume key events to AccessibilityService.
  The overlay still updates while visible using a short sampling burst.
- This does not truly replace the system volume UI; it overlays your UI on top.
